# Task: cafeteria-alumni — Build Cafeteria/Meal Plan view + Alumni tracking view

Agent: full-stack-developer
Task ID: cafeteria-alumni
Project: EduCenterJM (Next.js 16 + Prisma + shadcn/ui SPA)

## Summary
Built 2 new view components (`CafeteriaView` and `AlumniView`) following the established patterns in the codebase. Both files start with `'use client'`, use the `api()` fetch helper from `@/lib/api`, consume `useAppStore`, render through shadcn/ui + lucide-react, and follow the polished emerald-gradient banner pattern (with two decorative blur blobs) used by library/dashboard/analytics/health/transport views.

## Reference files read first
- `/home/z/my-project/worklog.md` (prior agents' work + 4 prior cron rounds)
- `/home/z/my-project/src/lib/store.ts` — useAppStore exposes `user`, `setActiveView`, `addToast`, `setViewUserId`
- `/home/z/my-project/src/lib/api.ts` — `api()`, `timeAgo()`, `gradeToForm()`
- `/home/z/my-project/src/lib/types.ts` — confirmed `MealAccount`, `MealTransaction`, `Alumni`, `Student` interfaces (all already declared in ViewId union: 'cafeteria' | 'alumni')
- `/home/z/my-project/src/components/app/views/library.tsx` — polished header + StatCard + dialog pattern reference
- `/home/z/my-project/src/components/app/views/dashboard.tsx` — load-in-useEffect with `active` flag + StatCard pattern
- `/home/z/my-project/src/components/app/views/students.tsx` — table + Dialog + CSV export + searchable student picker patterns
- `/home/z/my-project/src/components/app/views/transport.tsx` — AssignStudentsDialog pattern (search Input + scrollable list capped at 200)
- `/home/z/my-project/src/components/app/user-avatar.tsx` — `<UserAvatar name avatar role size />`
- Verified backend routes exist with the expected JSON shapes: `/api/meal-accounts` (GET/POST), `/api/meal-accounts/[id]` (PATCH/DELETE), `/api/meal-transactions` (GET/POST), `/api/alumni` (GET/POST), `/api/students` (GET)

## Files created

### 1. `src/components/app/views/cafeteria.tsx` (~900 lines, `export function CafeteriaView()`)
Role-aware Cafeteria / Meal Plan view (Admin, Principal, Student). Polished emerald→teal→cyan gradient header with 2 blur blobs and UtensilsCrossed icon.

**Staff branch (Admin/Principal):**
- 4 hover-lift StatCards: Total Accounts, Total Balance (`formatMoney(cents)` $X.XX), Active Plans, Students with Dietary Restrictions.
- Accounts table: avatar + name + "updated {timeAgo}", meal plan badge (Standard=emerald, Premium=amber, Basic=teal), balance (colored: emerald >$5, amber $1–$5, rose <$1), dietary tag chips (color-coded: Vegetarian=emerald, Halal=teal, Gluten-Free=amber, Kosher=cyan, Dairy-Free=rose, Nut-Free=orange). Row actions: Top Up + Transactions buttons.
- **Create Account dialog**: searchable student picker (filters out students who already have accounts), meal plan Select, dietary tag Checkboxes (6 tags), initial balance $ input (converted to cents on submit). POST `/api/meal-accounts`.
- **Top Up dialog**: amount $ input + description + quick-amount chips ($10/$20/$50/$100). POST `/api/meal-transactions` body `{ accountId, type: 'Topup', amount: cents, description }`.
- **Transactions modal**: lazy-loads GET `/api/meal-transactions?accountId=X` when opened; shows transaction rows with type badge (Topup=emerald, Purchase=amber) + signed amount + description + date.

**Student branch:**
- Large gradient balance card with prominent $X.XX display, meal plan badge, dietary tag chips, low-balance amber warning when balance < $5 (critically low when <$1), Request Top-Up button (mock — shows info toast saying the request was sent to the finance office), and Dietary Preferences button.
- Today's Menu card: mock Jamaican cafeteria menu (Breakfast / Lunch / Snacks) with item name, price, dietary tags, and a "Buy Now" button that POSTs a Purchase transaction (negative amount). Disabled with "Insufficient" label when balance < item price.
- Recent Transactions list (max-h-96 scroll): transaction rows with type badge + signed amount + description + date.
- **Edit Preferences dialog**: PATCH `/api/meal-accounts/[id]` with `{ mealPlan, dietaryTags }`.

**Cross-cutting:**
- Currency: `formatMoney = (cents) => '$' + (cents / 100).toFixed(2)` for both balances and transaction amounts.
- All `setState` calls happen after `await` inside `useEffect` with `let active = true` flag guard (complies with `react-hooks/set-state-in-effect` rule).
- Loader2 spinners + empty states throughout.
- Emerald/teal/cyan/amber/rose accent theme (NO indigo/blue).

### 2. `src/components/app/views/alumni.tsx` (~470 lines, `export function AlumniView()`)
Admin/Principal-only Alumni tracking view. Same polished emerald→teal→cyan gradient header with GraduationCap icon. Subtitle "Directory of graduated students and their accomplishments."

**Layout:**
- 4 hover-lift StatCards: Total Alumni, This Year's Graduates (`gradYear === currentYear`), With Contact Info (email OR phone present), Graduate Studies (mock 68% of total).
- Search bar: debounced 350ms search by name/email/admissionNo — calls `GET /api/alumni?q=...`. Shows a spinner while searching and an X clear button.
- Alumni grid (sm:2, lg:3 columns): each card has gradient top bar (emerald→teal→cyan), UserAvatar (lg), name + Class of {gradYear} badge + admissionNo badge, last form (via `gradeToForm(lastGrade)`) + last class info row with BookOpen/Users icons, mailto: + tel: links (mail/phone icons, hover-emerald), truncated 3-line bio, "View Profile" outline button (emerald-tinted) that calls `setViewUserId(alumnus.id)` + `setActiveView('profile')`.
- Export CSV button in header (matches students.tsx `downloadCSV` pattern) — exports name/email/admission_no/grad_year/last_form/last_class/phone/bio/status.
- Graduate a Student dialog: searchable picker over `students.filter(s => s.status === 'Active')`, list capped at 200, shows admissionNo + form + class. On confirm POSTs `/api/alumni` with `{ studentId }` then refreshes the alumni list. Shows a success toast + emerald-tinted "Ready to graduate {name}" preview panel when a student is selected.

**Cross-cutting:**
- All `setState` calls happen after `await` inside `useEffect` with `active` flag guard.
- Loader2 spinner + empty states (with "Graduate a Student" CTA in the empty state).
- Emerald/teal/cyan/amber accent theme (NO indigo/blue).

## Verification
- `cd /home/z/my-project && bun run lint` → exit code 0, **0 errors, 0 warnings** (after removing unused imports: `Apple` icon in cafeteria.tsx; `Select` family, `STAFF_ROLES`, `user` local var, and an unneeded eslint-disable comment in alumni.tsx).
- Dev server log shows clean `✓ Compiled` entries with no exceptions or Prisma errors after the new files were created.
- No existing files were modified — only the 2 new view files were created.

## Notes for the orchestrator
- Both `CafeteriaView` and `AlumniView` are exported as named exports and ready to be wired into the AppShell switch under view IDs `'cafeteria'` and `'alumni'` (both already present in the `ViewId` union in `src/lib/types.ts`).
- Suggested nav gating: Cafeteria visible to Admin/Principal/Student; Alumni visible to Admin/Principal only.
