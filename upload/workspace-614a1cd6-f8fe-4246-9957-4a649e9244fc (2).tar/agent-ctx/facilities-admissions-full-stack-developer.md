# Task: facilities-admissions — Facilities Booking + Admissions views

## Files Created
- `src/components/app/views/facilities.tsx` — `export function FacilitiesView()`
- `src/components/app/views/admissions.tsx` — `export function AdmissionsView()`

## facilities.tsx (Facilities Booking)
- 'use client' client component, emerald accent theme (NO indigo/blue).
- Polished emerald→teal→cyan gradient header banner with 2 blur blobs + `DoorOpen` icon. Subtitle "Reserve rooms, labs, and school facilities." Header buttons: "Book Facility" (all staff) + "Add Facility" (staff only — Admin/Principal/Teacher).
- 4 hover-lift StatCards: Total Facilities / Bookable / Active Bookings (Approved) / Pending Requests (amber when >0, slate otherwise). Each card scales icon on hover and shows an ArrowRight that fades in.
- Two-column layout (lg:grid-cols-3). Left col-span-2 = facilities grid. Right = bookings list.
- Facilities grid (sm:grid-cols-2): each card has a color-bar on top (1.5px) + type icon tile + name + type subtitle + type badge chip + capacity (Users icon) + location (MapPin icon) + bookingCount (CalendarClock icon) + optional notes (line-clamp-2) + isBookable pill (emerald "Bookable" / slate "Closed" with colored dot) + Edit (Pencil, staff only) + Book (Calendar) buttons. Book button disabled when `!isBookable`.
- Type color mapping (per spec): Room=emerald, Lab=teal, Hall=amber, Field=cyan, Equipment=violet. Each entry has `badge`, `bar`, and `icon` (DoorOpen / Building2 / Users / LayoutGrid / CalendarClock respectively).
- Bookings list card: CardHeader with CalendarClock title + count. CardContent has a `max-h-96 overflow-y-auto` scroll container with one border-card per booking showing: title + facility type chip + facility name + BookingStatusBadge (Pending=amber, Approved=emerald, Rejected=rose) + date (Calendar) + time range (Clock) + purpose (line-clamp-2) + requested-by + timeAgo. For staff viewing Pending bookings: inline Approve (Check, emerald) + Reject (X, rose) ghost buttons that call PATCH /api/bookings/[id] with status. Shows `reviewedByName` for already-reviewed bookings. Empty state has CalendarClock icon + New Booking CTA.
- BookingDialog (Book a Facility): facility Select (only bookable facilities), title Input, purpose Textarea, date Input (type=date, defaults to today), start/end time Input (type=time, defaults 09:00–10:00). Validates: facilityId required, title required, endTime > startTime. POST /api/bookings. Loading spinner on submit button.
- FacilityDialog (Add/Edit, staff only): name Input, type Select (5 types), capacity number Input (min 1), location Input, isBookable Switch with helper label "Allow staff to submit reservation requests" inside a bordered box, notes Textarea. POST /api/facilities (add) or PATCH /api/facilities/[id] (edit).
- useEffect load with `let active = true` flag — all setState calls happen AFTER await. No synchronous setState in effect body.
- Loading state: full-width Card with Loader2 spinner (h-64). Empty states: facilities grid empty shows Building2 icon + Add Facility CTA (staff only); bookings list empty shows CalendarClock icon + New Booking CTA.
- Extended `Facility` type locally as `BaseFacility & { bookingCount?: number }` since the shared types.ts interface omits `bookingCount` (which the API returns).

## admissions.tsx (Admissions module)
- 'use client' client component, emerald accent theme.
- Same polished emerald gradient header banner + 2 blur blobs + `ClipboardPaste` icon. Subtitle "Track applications and manage enrollment." Header button: "New Application".
- 4 hover-lift StatCards: Total Applications / Pending Review (amber when >0) / Accepted / Enrolled.
- Filter tabs (shadcn Tabs): All | Pending | Reviewing | Accepted | Rejected | Enrolled. Used as a segmented control (no TabsContent — purely a filter). Search input (w-64) on the right: searches applicantName / email / parentName / previousSchool.
- Applications table: Applicant Name (gradient avatar with `initials()`) + Email; Grade Applied (Badge with `gradeToForm()`); Parent/Guardian + phone; Previous School; Status badge color-coded (Pending=amber, Reviewing=cyan — NOT blue per spec, Accepted=emerald, Rejected=rose, Enrolled=teal); Actions column with three controls:
  - View (Eye icon button → opens DetailDialog)
  - Update Status (MoreVertical icon button → DropdownMenu with Mark Reviewing / Accept / Reject / Enroll items, each disabled when matching current status; Enroll triggers `confirm()` warning that this creates a student login account)
  - Delete (Trash2 icon button, rose-tinted, with confirm)
- ApplicationDialog (New Application): applicantName*, email*, phone, dob (date), gender select (Male/Female/Other), gradeApplied select (7-13 mapped via gradeToForm), parentName, parentPhone, parentEmail (full-width), address (full-width), previousSchool (full-width). Validates name + email. POST /api/admissions.
- DetailDialog (Application Details): header summary card (avatar + applicantName + "Applied {timeAgo}" + gradeApplied + status badge); Status Timeline card (4-step Submitted→Reviewing→Accepted→Enrolled with done circles showing Check or step number; special 3-step Submitted→Reviewing→Rejected branch for rejected apps, including reviewed-by note); details grid (2-col, 10 Detail rows with icons: Email, Phone, DOB, Gender, Grade Applied, Previous School, Parent/Guardian, Parent Phone, Parent Email, Address); reviewed-by line; internal Notes Textarea + Save Notes button (PATCH /api/admissions/[id] with notes only); Separator; action buttons row: Mark Reviewing / Accept / Reject / Enroll (Enroll reveals an inline amber confirmation card with ShieldAlert warning that "this will create a student login account for {name}" + Confirm Enrollment button) / Delete. Action buttons hidden when matching current status to prevent no-op.
- Loading state: Loader2 spinner (h-64). Empty state: ClipboardPaste icon + Clear filters CTA.
- useEffect load with `active` flag — all setState after await. `updateStatus` re-fetches admissions list + updates `viewing` dialog with refreshed data so the timeline/badges re-render immediately.
- Did NOT use `CalendarYear` (doesn't exist). Pre-verified all icons exist via `node -e "require('lucide-react')"`.

## Verification
- `cd /home/z/my-project && bun run lint` → exit code 0, ZERO errors, ZERO warnings.
- `npx tsc --noEmit -p tsconfig.json` → ZERO errors in either new file (pre-existing errors in cafeteria.tsx / reports.tsx / src/lib/seed.ts / examples/ / skills/ remain unrelated and were not touched).
- Verified all 28 lucide-react icons exist (DoorOpen, ClipboardPaste, Plus, Search, Eye, Trash2, Check, X, UserPlus, Loader2, Send, Mail, Phone, Home, GraduationCap, Calendar, ArrowRight, Inbox, CheckCircle2, PenLine, ShieldAlert, FileText, MoreVertical, Building2, MapPin, Users, CalendarClock, Clock, Pencil, LayoutGrid).
- Dev log shows clean `✓ Compiled in 206ms` — no exceptions.
- Did NOT modify any existing files — only created the 2 new view files. AppShell switch + nav config wiring is left to the orchestrator (nav.ts already declares `facilities` (Admin/Principal/Teacher) and `admissions` (Admin/Principal) entries — the app-shell.tsx `case 'facilities':` / `case 'admissions':` switch arms still need to be added by the orchestrator).

## Backend Routes Used (already exist)
- `GET /api/facilities` → `{ facilities: Facility[] & { bookingCount } }`. `POST /api/facilities` (staff only). `PATCH/DELETE /api/facilities/[id]` (staff only).
- `GET /api/bookings?status=X` → `{ bookings: Booking[] }`. `POST /api/bookings` body `{ facilityId, title, purpose, date, startTime, endTime }`. `PATCH /api/bookings/[id]` body `{ status }` (staff only, sets reviewedById). `DELETE /api/bookings/[id]`.
- `GET /api/admissions?status=X` → `{ admissions: Admission[] }`. `POST /api/admissions` body `{ applicantName, email, phone, dob, gender, gradeApplied, parentName, parentPhone, parentEmail, address, previousSchool }`. `PATCH /api/admissions/[id]` body `{ status, notes }` (staff only; status=Enrolled auto-creates student account). `DELETE /api/admissions/[id]` (staff only).
