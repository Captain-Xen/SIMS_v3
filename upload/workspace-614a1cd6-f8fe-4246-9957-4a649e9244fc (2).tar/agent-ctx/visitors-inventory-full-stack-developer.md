# Task: visitors-inventory — Visitor Management + Inventory views

## Files Created
- `src/components/app/views/visitors.tsx` — `export function VisitorsView()`
- `src/components/app/views/inventory.tsx` — `export function InventoryView()`

## visitors.tsx (Visitor Management)
- 'use client' client component, emerald accent theme (NO indigo/blue).
- Polished emerald→teal→cyan gradient header banner with 2 blur blobs + `UserCheck` icon + "Check In Visitor" button.
- 4 hover-lift StatCards: Currently Checked In / Total Today / Checked Out Today / Total This Week (computed in useMemo via isSameDay/isThisWeek helpers).
- Filter tabs: All | Checked In | Checked Out — with count chips.
- Visitors table: Visitor name + phone/email meta, color-coded Purpose badge (Meeting=emerald, Delivery=teal, Maintenance=amber, Parent Visit=cyan, Other=slate), Visiting Whom, Check-In time (HH:MM + timeAgo), Check-Out time, monospace Gate Pass No badge (emerald-outlined), Status badge (CheckedIn=emerald with animated pulse dot, CheckedOut=muted).
- Row actions: Print Gate Pass (Printer icon — only shown when checked in), Check Out (LogOut icon + amber accent), Delete (Trash2 icon).
- Check In Visitor dialog: name*, phone, email, purpose select, visiting whom input. On submit POST /api/visitors and toast the returned gatePassNo.
- Print Gate Pass: `window.open('', '_blank')` + `document.write` with a styled printable gate pass — emerald gradient header, GP-XXXX badge, visitor info rows, signature lines, auto `window.print()` on load, escapeHtml to prevent injection.
- useEffect load with `let active = true` flag — all setState calls happen after `await` (no synchronous setState in effect body).
- Loading: Loader2 spinner. Empty state: UserX icon + "Check In Visitor" CTA button.

## inventory.tsx (Inventory / Asset Management)
- 'use client' client component, emerald accent theme.
- Same polished emerald gradient header banner + 2 blur blobs + `PackageOpen` icon + "Add Item" button.
- 4 hover-lift StatCards: Total Items / Low Stock (amber when > 0, teal otherwise) / Categories / Total Value (mock — total units).
- Low stock alert card: amber-tinted Card with AlertTriangle icon — lists up to 8 low-stock items as chips showing `name qty/min unit`, plus "+N more" overflow chip.
- Toolbar: search bar (name/location/notes), category filter Select (All + 6 categories), Export CSV button (downloadCSV helper).
- Inventory table: Item name + notes + "Updated {timeAgo}", color-coded Category badge (Equipment=emerald, Furniture=teal, Lab Supply=amber, Textbook=violet, Stationery=cyan, General=slate), Quantity with inline +/- buttons (ArrowDown/ArrowUp) + colored qty chip (amber when low, emerald otherwise), Condition badge (New=emerald, Good=teal, Fair=amber, Poor=rose), Location with MapPin icon, Min Stock cell (amber warning chip with AlertTriangle when quantity <= minStock, else muted text).
- Row actions: Edit (Pencil, opens ItemDialog), Delete (Trash2).
- Adjust Quantity: inline +/- buttons call PATCH /api/inventory/[id] with new quantity, optimistic local state update + toast.
- ItemDialog (Add/Edit): name*, category select, quantity (number), unit select (pcs/boxes/sets/books), condition select, location (text), minStock (number), notes (Textarea). Separator before footer. POST/PATCH /api/inventory.
- Export CSV: builds CSV blob, triggers download as `inventory_YYYY-MM-DD.csv`, toasts success.
- useEffect load with `active` flag — all setState after await.
- Loading + empty state (PackageOpen icon + Add Item CTA).

## Verification
- `cd /home/z/my-project && bun run lint` → exit code 0, ZERO errors, ZERO warnings.
- Verified all 30 lucide-react icons exist (UserCheck, PackageOpen, Plus, Search, Pencil, Trash2, Download, AlertTriangle, ArrowUp, ArrowDown, Loader2, X, Send, Mail, Phone, Clock, LogIn, LogOut, Printer, UserX, Filter, ArrowRight, Package, Boxes, MapPin, Calendar, TrendingUp, UserPlus, ClipboardList, CheckCircle2, ChevronDown, FileText) via `node -e "require('lucide-react')"`.
- Dev log shows clean `✓ Compiled` entries — no exceptions when files were processed.
- Did NOT modify any existing files — only created the 2 new view files. AppShell switch + nav config wiring is left to the orchestrator.

## Backend Routes Used (already exist)
- `GET /api/visitors` → `{ visitors: Visitor[] }`
- `POST /api/visitors` body `{ name, phone, email, purpose, visitingWhom }` → `{ ok, id, gatePassNo }`
- `PATCH /api/visitors/[id]` (check-out — sets status=CheckedOut, checkOutTime=now)
- `DELETE /api/visitors/[id]`
- `GET /api/inventory?category=X` → `{ items: InventoryItem[] }`
- `POST /api/inventory` body `{ name, category, quantity, unit, condition, location, minStock, notes }` (staff only) → `{ ok, id }`
- `PATCH /api/inventory/[id]` (supports partial updates — quantity only is fine)
- `DELETE /api/inventory/[id]` (staff only)

## Suggested Nav Gating (for orchestrator)
- `visitors` view: Admin, Principal, Ancillary Staff
- `inventory` view: Admin, Principal

Both ViewId values `visitors` and `inventory` are already declared in the ViewId union in `/lib/types.ts`.
