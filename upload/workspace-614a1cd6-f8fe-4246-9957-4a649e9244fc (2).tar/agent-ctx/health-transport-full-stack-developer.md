# Task: health-transport — Build Health Records + Transportation views

**Task ID:** health-transport
**Agent:** full-stack-developer
**Date:** current round

## What I built

### 1. `src/components/app/views/health.tsx` — `export function HealthView()`
Health Records view (visible to Nurse, Admin, Principal).

- **Header**: Polished emerald gradient banner with 2 decorative blur blobs, `HeartPulse` icon, "Add Record" button (gated to ALLOWED_ROLES = Admin/Principal/Nurse).
- **4 hover-lift StatCards**: Total Records, Critical Allergies (rose icon when >0), Active Medications, Immunizations. Each has a decorative gradient circle + `group-hover:scale-110` icon.
- **Type filter tabs**: All / Allergies / Conditions / Medications / Immunizations / Clinic Visits — each tab shows a count chip; active tab is emerald-tinted with an emerald-600 count chip.
- **Search Input**: filters by title / studentName / description / recordedByName.
- **Records list** as cards: each card has a colored top tint bar (type-colored), student UserAvatar, title (bold) + type badge (color-coded per spec) + severity badge (Critical=rose, High=orange, Moderate=amber, Low=emerald), description (line-clamp-3), date with CalendarClock icon, recorded-by with Stethoscope icon, timeAgo(createdAt). Edit + Delete buttons on the right (delete uses confirm() + per-id loading spinner).
- **Add/Edit Dialog**: searchable student Select (Input with stopPropagation inside SelectContent to filter the dropdown, capped at 100 results), type Select (with type-icon prefix), severity Select, title Input, description Textarea, date Input. POST /api/health, PATCH /api/health/[id], DELETE /api/health/[id]. Validation requires studentId + title.
- **Loading state**: Loader2 spinner in a centered Card. **Empty state**: HeartPulse icon + CTA "Add the first record".
- Emerald/teal/cyan/rose/amber accent theme — NO indigo/blue. All setState calls happen after `await` inside useEffect (with `active` flag guard).

### 2. `src/components/app/views/transport.tsx` — `export function TransportView()`
Transportation / Bus Routes view (visible to Admin, Principal, Student). Role-aware branches.

**Header**: Same polished emerald gradient banner with Bus icon. Subtitle switches by role.

**STAFF branch** (Admin/Principal):
- **4 StatCards**: Total Routes / Total Assignments / Total Capacity / Utilization Rate % (utilization amber when >90%).
- **Routes grid** (md:grid-cols-2): each card has gradient top bar (emerald→teal→cyan), routeName with Bus icon, driverName with UserIcon, capacity badge (rose when full), 2x2 info grid (driverPhone / vehicleNo / morningPickup / eveningDrop), utilization Progress bar (rose class when full), stops as emerald-tinted outline Badges, action row: "Assign Students" button (disabled + "Route Full" when at capacity) / Edit / Delete.
- **Assignments table**: student avatar + name, class Badge, route name with Bus icon, assigned date, Remove button (rose, per-id loading spinner).
- **Add/Edit Route Dialog**: routeName + driverName (both required), driverPhone, vehicleNo, capacity (number ≥1), morningPickup / eveningDrop (`type="time"` inputs), stops Input (comma-separated → split + trim → array on save).
- **AssignStudentsDialog**: search Input, scrollable list (max 200) of students with avatars + admissionNo + className — each row shows "On {routeName}" badge if on another route, "On route" badge if already on this route, or an Assign button (disabled when full). POST /api/bus-assignments `{ routeId, studentId }`. Calls `onSaved` (which triggers parent refresh) after each successful assignment so the dialog stays open for batch assignment but the parent UI reflects the new count.

**STUDENT branch**:
- Derives `myAssignment` + `myRoute` from the `/api/bus-assignments` response (backend already filters to student's own).
- **If unassigned**: friendly "You are not currently assigned to a bus route" card with amber Bus icon tile + dashed-border tip about bringing student ID to the transportation office.
- **If assigned**: 3-col grid:
  - Main route card (lg:col-span-2): driver contact section (Call Driver tel: link + Message sms: link as anchor-styled Buttons), 4 InfoTiles (Morning Pickup / Evening Drop-off / Vehicle Number / Bus Capacity), utilization Progress bar, numbered stops as emerald Badges.
  - Side column: "Assignment Details" card (assigned-on date / class / Active status) + amber "Need to change routes?" info card.

**CRUD endpoints used**:
- `/api/routes` (GET all / POST staff-only) + `/api/routes/[id]` (PATCH / DELETE staff-only)
- `/api/bus-assignments` (GET role-filtered / POST staff-only with capacity check / DELETE staff-only body `{ id }`)

## Verification
- `bun run lint` → **exit code 0**, zero errors, zero warnings.
- Dev server log shows clean "✓ Compiled" entries with no exceptions or runtime errors.

## Files Created
- `/home/z/my-project/src/components/app/views/health.tsx`
- `/home/z/my-project/src/components/app/views/transport.tsx`

## Files NOT modified
- types.ts (ViewId 'health' + 'transport' already declared by orchestrator)
- store.ts, api.ts (used as-is)
- app-shell.tsx + nav config (left to orchestrator to wire switch + nav entries)

## Patterns Followed
- `'use client'` at top of every file
- `import { api } from '@/lib/api'` + `import { useAppStore } from '@/lib/store'` + `import type { ... } from '@/lib/types'`
- useEffect with `active` flag; all `setState` calls happen AFTER `await` to comply with the `react-hooks/set-state-in-effect` rule
- shadcn/ui (Card, CardContent, CardHeader, CardTitle, CardDescription, Button, Input, Label, Badge, Progress, Separator, Select, Dialog, Textarea)
- lucide-react icons throughout
- `cn()` for conditional classes
- Polished emerald-gradient header pattern from library.tsx (with 2 blur blobs + shadow-xl + backdrop-blur button)
- Loader2 spinners + empty states throughout
- NO indigo/blue colors anywhere
