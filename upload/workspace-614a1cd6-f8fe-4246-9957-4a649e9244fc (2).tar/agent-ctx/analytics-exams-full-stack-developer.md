# Task analytics-exams — full-stack-developer

## Task
Build 2 NEW view components for EduCenterJM SPA:
1. School Analytics view (`/home/z/my-project/src/components/app/views/analytics.tsx`) — `AnalyticsView`
2. Exam Management view (`/home/z/my-project/src/components/app/views/exams.tsx`) — `ExamsView`

## Work Log
1. Read `/home/z/my-project/worklog.md` to understand prior agent work (Task 0 main orchestrator + Task 6-A which built 11 existing-feature views).
2. Read reference files to lock down exact patterns:
   - `src/lib/store.ts` — `useAppStore` with `user`, `setActiveView`, `addToast`.
   - `src/lib/api.ts` — `api()` fetch helper + `gradeToForm()` + `scoreToLetter()`.
   - `src/lib/types.ts` — `Exam`, `Student`, `Staff`, `Grade`, `Attendance`, `Fee` interfaces.
   - `src/components/app/views/dashboard.tsx` — recharts patterns, emerald gradient banner, StatCard helper.
   - `src/components/app/views/library.tsx` — polished header with blur blobs, dialog + table patterns.
   - `src/components/app/views/students.tsx` — table + edit dialog pattern, role gating.
   - `src/app/api/exams/route.ts` + `[id]/route.ts` — confirmed `GET` filters by student class, `POST/PATCH/DELETE` staff-only.
3. Created `analytics.tsx`:
   - Emerald gradient banner with two blur blobs + BarChart3 icon, "Live snapshot" badge.
   - 4 hover-lift StatCards: Total Students, Total Staff, Avg Grade Score, Attendance Rate.
   - 6 recharts visualisations:
     a) Enrollment by Form — BarChart (emerald bars, mapped via gradeToForm).
     b) Grade Distribution by Subject — vertical BarChart with per-bar Cell color (≥80 emerald, ≥60 teal, ≥40 amber, <40 red) + legend dots.
     c) Attendance Breakdown — donut PieChart (emerald/amber/red).
     d) Performance Trend — AreaChart with gradient `trendFill` def, simulated 6-term upward trend from current avg.
     e) Gender Distribution — donut PieChart (teal/cyan).
     f) Fee Collection Status — BarChart with $ formatter, emerald (paid) vs amber (pending).
   - Auto-generated Insights card with good/warn/info styled findings (top subject, weak subject, best attendance class, avg grade letter, attendance rate, fee % collected, largest cohort, gender split).
   - Loading state (Loader2), empty states per chart, STAFF_ONLY role gate.
   - `useEffect` with `let active = true` flag — no setState after unmount.
4. Created `exams.tsx`:
   - Emerald gradient banner with GraduationCap icon + "Print Timetable" button (both roles) + "Schedule Exam" button (staff only).
   - Staff view: 4 StatCards (Total Exams, Upcoming, Subjects, Classes Affected); class filter Select; full timetable table with Title/Subject badge/Class badge/Date/Time/Room/Marks/Actions columns; Edit (Pencil) + Delete (Trash2 with confirm + Loader2 spinner) row actions.
   - Staff create/edit dialog: title, subject select (10 subjects), class select (12 classes), date input, time input, duration (default 120), room, totalMarks (default 100), passingMarks (default 40), notes textarea. Validation with toasts. POST `/api/exams` for create, PATCH `/api/exams/[id]` for edit.
   - Student view: count badge card ("You have X upcoming exams" with next exam preview); sorted upcoming exam cards with left-border urgency color (≤3 days = amber, ≤7 days = emerald, else muted), badges + meta row (date/time/room/marks), notes line.
   - Print Timetable: `window.open('', '_blank')` + `document.write` with emerald-styled HTML table, auto-`print()` after 300ms; pop-up-blocked toast fallback.
   - Loading state (Loader2), empty states for staff and student; role gating via `STAFF_ROLES` includes Vice Principal.
5. Ran `cd /home/z/my-project && bun run lint` — exit code 0, no errors in either new file (or anywhere else).
6. Verified dev server log shows clean `✓ Compiled` with no errors after files were created.

## Files Created
- `/home/z/my-project/src/components/app/views/analytics.tsx` — `AnalyticsView` (~430 lines, 6 charts + insights + 4 stat cards)
- `/home/z/my-project/src/components/app/views/exams.tsx` — `ExamsView` (~520 lines, staff + student variants, CRUD dialog, print)

## Patterns Reused (from prior agents)
- Emerald gradient banner + 2 blur blobs (from library.tsx / dashboard.tsx).
- `useEffect` + `let active = true` + `try/catch/finally` data loading with `setLoading(false)` in finally.
- shadcn `Dialog open onOpenChange={onClose}` + `DialogHeader/Title/Footer` + single `form` state object via `setForm({ ...form, field: value })`.
- Plain HTML `<table>` with hover rows (matches students.tsx).
- Recharts `ResponsiveContainer` + `PieChart`/`BarChart`/`AreaChart` with `Cell`-based per-bar colors and `defs` linear gradients.
- StatCard helper with `colors[color]` map (emerald/teal/amber/cyan/red/slate).
- `cn()` from `@/lib/utils` for conditional border/urgent styling.

## Notes for orchestrator
- Did NOT modify any existing files (nav.ts, app-shell.tsx, types.ts left to orchestrator).
- The two views are ready to be wired into the AppShell switch and the nav config under view IDs `'analytics'` and `'exams'` (both already declared in `ViewId` union in `src/lib/types.ts`).
- All API endpoints used (`/api/students`, `/api/staff`, `/api/grades`, `/api/attendance`, `/api/fees`, `/api/exams`, `/api/exams/[id]`) already exist and return the documented shapes.
