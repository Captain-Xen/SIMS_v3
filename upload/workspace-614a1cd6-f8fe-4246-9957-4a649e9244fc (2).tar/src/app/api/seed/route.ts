import { NextResponse } from 'next/server'
import { seedDatabase } from '@/lib/seed'

export async function POST() {
  try {
    const result = await seedDatabase()
    return NextResponse.json({ ok: true, ...result })
  } catch (e: any) {
    console.error('Seed failed:', e)
    return NextResponse.json({ error: e?.message || 'Seed failed' }, { status: 500 })
  }
}
