import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSession } from '@/lib/auth'

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || session.role === 'Student') return NextResponse.json({ error: 'Staff only' }, { status: 403 })
  const { id } = await params
  const body = await req.json()
  const data: any = {}
  for (const k of ['name', 'type', 'location', 'notes']) {
    if (body[k] !== undefined) data[k] = body[k]
  }
  if (body.capacity !== undefined) data.capacity = Number(body.capacity)
  if (body.isBookable !== undefined) data.isBookable = body.isBookable
  const facility = await db.facility.update({ where: { id }, data })
  return NextResponse.json({ ok: true, facility })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession()
  if (!session || session.role === 'Student') return NextResponse.json({ error: 'Staff only' }, { status: 403 })
  const { id } = await params
  await db.facility.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
