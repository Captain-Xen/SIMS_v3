import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSession } from '@/lib/auth'

export async function GET() {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const items = await db.announcement.findMany({ include: { author: true }, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({
    announcements: items.map((a: any) => ({
      id: a.id,
      title: a.title,
      body: a.body,
      authorName: a.author?.name ?? 'System',
      authorRole: a.author?.role ?? '',
      createdAt: a.createdAt.toISOString(),
    })),
  })
}

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { title, body } = await req.json()
  const a = await db.announcement.create({ data: { title, body, authorId: session.id } })
  // notify all users
  const users = await db.user.findMany()
  await db.notification.createMany({
    data: users.map((u) => ({ userId: u.id, title: `Announcement: ${title}`, body: body.slice(0, 120), type: 'info' })),
  })
  return NextResponse.json({ ok: true, id: a.id })
}

export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await req.json()
  await db.announcement.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
