'use client'

import { useEffect, useState, useRef } from 'react'
import {
  GraduationCap, Menu, Search, Moon, Sun, Bell, LogOut, ChevronLeft, ChevronRight,
  PanelLeftClose, PanelLeft,
} from 'lucide-react'
import { api } from '@/lib/api'
import { useAppStore } from '@/lib/store'
import { navForRole, VIEW_TITLES } from './nav'
import { UserAvatar } from './user-avatar'
import { SearchModal } from './search-modal'
import { ToastContainer } from './toast-container'
import { DashboardView } from './views/dashboard'
import { ProfileView } from './views/profile'
import { StudentsView } from './views/students'
import { StaffView } from './views/staff'
import { GradesView } from './views/grades'
import { AttendanceView } from './views/attendance'
import { TimetableView } from './views/timetable'
import { FeesView } from './views/fees'
import { AnnouncementsView } from './views/announcements'
import { DisciplineView } from './views/discipline'
import { MessagesView } from './views/messages'
import { AssignmentsView } from './views/assignments'
import { NotificationsView } from './views/notifications'
import { ImportView } from './views/import'
import { SettingsView } from './views/settings'
import { SubjectsView } from './views/subjects'
import { AddRecordView } from './views/add-record'
import { LibraryView } from './views/library'
import { EventsView } from './views/events'
import { ParentPortalView } from './views/parent-portal'
import { ReportsView } from './views/reports'
import { HelpView } from './views/help'
import { AnalyticsView } from './views/analytics'
import { ExamsView } from './views/exams'
import { HealthView } from './views/health'
import { TransportView } from './views/transport'
import { CafeteriaView } from './views/cafeteria'
import { AlumniView } from './views/alumni'
import { VisitorsView } from './views/visitors'
import { InventoryView } from './views/inventory'
import { FacilitiesView } from './views/facilities'
import { AdmissionsView } from './views/admissions'
import { TermsView } from './views/terms'
import { PerformanceView } from './views/performance'
import { FinanceView } from './views/finance'
import { ConferenceView } from './views/conference'
import { ActivitiesView } from './views/activities'
import { UniformView } from './views/uniform'
import { cn } from '@/lib/utils'
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'

const IDLE_LIMIT = 7 * 60 * 1000 // 7 minutes
const WARNING_DURATION = 60 // seconds

export function AppShell() {
  const user = useAppStore((s) => s.user)
  const setUser = useAppStore((s) => s.setUser)
  const activeView = useAppStore((s) => s.activeView)
  const setActiveView = useAppStore((s) => s.setActiveView)
  const theme = useAppStore((s) => s.theme)
  const toggleTheme = useAppStore((s) => s.toggleTheme)
  const settings = useAppStore((s) => s.settings)
  const sidebarCollapsed = useAppStore((s) => s.sidebarCollapsed)
  const toggleSidebar = useAppStore((s) => s.toggleSidebar)
  const setSearchOpen = useAppStore((s) => s.setSearchOpen)
  const addToast = useAppStore((s) => s.addToast)

  const [logoutOpen, setLogoutOpen] = useState(false)
  const [loggingOut, setLoggingOut] = useState(false)
  const [idleWarning, setIdleWarning] = useState(false)
  const [idleCountdown, setIdleCountdown] = useState(WARNING_DURATION)
  const [unreadCount, setUnreadCount] = useState(0)
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const countdownTimer = useRef<ReturnType<typeof setInterval> | null>(null)

  const nav = user ? navForRole(user.role) : []

  // Keyboard shortcut for search
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setSearchOpen(true) }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [setSearchOpen])

  // Idle timeout
  useEffect(() => {
    if (!user) return
    const reset = () => {
      if (idleTimer.current) clearTimeout(idleTimer.current)
      idleTimer.current = setTimeout(() => setIdleWarning(true), IDLE_LIMIT)
    }
    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart']
    events.forEach((e) => window.addEventListener(e, reset))
    reset()
    return () => {
      events.forEach((e) => window.removeEventListener(e, reset))
      if (idleTimer.current) clearTimeout(idleTimer.current)
    }
  }, [user])

  useEffect(() => {
    if (!idleWarning) return
    setIdleCountdown(WARNING_DURATION)
    countdownTimer.current = setInterval(() => {
      setIdleCountdown((c) => {
        if (c <= 1) {
          if (countdownTimer.current) clearInterval(countdownTimer.current)
          doLogout(true)
          return 0
        }
        return c - 1
      })
    }, 1000)
    return () => { if (countdownTimer.current) clearInterval(countdownTimer.current) }
  }, [idleWarning])

  // notification count poll
  useEffect(() => {
    if (!user) return
    let active = true
    async function load() {
      try {
        const res = await api<{ notifications: { read: boolean }[] }>('/api/notifications')
        if (active) setUnreadCount(res.notifications.filter((n) => !n.read).length)
      } catch { /* ignore */ }
    }
    load()
    const t = setInterval(load, 30000)
    return () => { active = false; clearInterval(t) }
  }, [user, activeView])

  async function doLogout(auto = false) {
    setLoggingOut(true)
    try {
      await api('/api/auth/logout', { method: 'POST' })
      setUser(null)
      addToast({ type: auto ? 'warning' : 'info', title: auto ? 'Logged out (idle)' : 'Signed out', body: auto ? 'You were inactive for too long.' : 'See you soon!' })
    } catch {
      setUser(null)
    } finally {
      setLoggingOut(false)
      setLogoutOpen(false)
      setIdleWarning(false)
    }
  }

  function renderView() {
    switch (activeView) {
      case 'dashboard': return <DashboardView />
      case 'profile': return <ProfileView />
      case 'subjects': return <SubjectsView />
      case 'add': return <AddRecordView />
      case 'students': return <StudentsView />
      case 'staff': return <StaffView />
      case 'grades': return <GradesView />
      case 'attendance': return <AttendanceView />
      case 'timetable': return <TimetableView />
      case 'fees': return <FeesView />
      case 'announcements': return <AnnouncementsView />
      case 'discipline': return <DisciplineView />
      case 'messages': return <MessagesView />
      case 'assignments': return <AssignmentsView />
      case 'notifications': return <NotificationsView />
      case 'library': return <LibraryView />
      case 'events': return <EventsView />
      case 'parent-portal': return <ParentPortalView />
      case 'reports': return <ReportsView />
      case 'analytics': return <AnalyticsView />
      case 'exams': return <ExamsView />
      case 'health': return <HealthView />
      case 'transport': return <TransportView />
      case 'cafeteria': return <CafeteriaView />
      case 'alumni': return <AlumniView />
      case 'visitors': return <VisitorsView />
      case 'inventory': return <InventoryView />
      case 'facilities': return <FacilitiesView />
      case 'admissions': return <AdmissionsView />
      case 'terms': return <TermsView />
      case 'performance': return <PerformanceView />
      case 'finance': return <FinanceView />
      case 'conference': return <ConferenceView />
      case 'activities': return <ActivitiesView />
      case 'uniform': return <UniformView />
      case 'help': return <HelpView />
      case 'import': return <ImportView />
      case 'settings': return <SettingsView />
      default: return <DashboardView />
    }
  }

  if (!user) return null

  function handleNavClick(v: typeof activeView) {
    setActiveView(v)
    setMobileNavOpen(false)
  }

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background">
      <div className="flex min-h-0 flex-1 overflow-hidden">
        {/* Desktop Sidebar */}
        <aside
          className={cn(
            'hidden shrink-0 flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300 md:flex',
            sidebarCollapsed ? 'w-20' : 'w-64'
          )}
        >
          {/* Logo */}
          <button
            onClick={() => setActiveView('dashboard')}
            className="flex h-16 items-center gap-3 border-b border-sidebar-border px-4 hover:bg-sidebar-accent/50"
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-md">
              {settings?.logo ? <img src={settings.logo} alt="School" className="h-full w-full object-cover" /> : <GraduationCap className="h-5 w-5" />}
            </div>
            {!sidebarCollapsed && (
              <div className="min-w-0 text-left">
                <p className="truncate font-serif text-base font-bold leading-tight">
                  <span className="text-emerald-600 dark:text-emerald-400">Edu</span>Center<span className="text-emerald-600 dark:text-emerald-400">JM</span>
                </p>
                <p className="truncate text-[10px] text-muted-foreground">{user.role} Portal</p>
              </div>
            )}
          </button>

          {/* Nav */}
          <nav className="flex-1 space-y-0.5 overflow-y-auto p-3">
            {nav.map((item) => {
              const Icon = item.icon
              const active = activeView === item.id
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveView(item.id)}
                  title={sidebarCollapsed ? item.label : undefined}
                  className={cn(
                    'group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
                    active ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground',
                    sidebarCollapsed && 'justify-center'
                  )}
                >
                  {active && !sidebarCollapsed && (
                    <span className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-white/80" />
                  )}
                  <Icon className={cn('h-5 w-5 shrink-0 transition-transform', active ? 'scale-110' : 'group-hover:scale-105')} />
                  {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
                  {item.id === 'notifications' && unreadCount > 0 && !sidebarCollapsed && (
                    <Badge className="ml-auto bg-red-500 px-1.5 py-0 text-[10px] text-white ring-2 ring-emerald-600/50">{unreadCount > 9 ? '9+' : unreadCount}</Badge>
                  )}
                  {item.id === 'notifications' && unreadCount > 0 && sidebarCollapsed && (
                    <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-sidebar" />
                  )}
                </button>
              )
            })}
          </nav>

          {/* Footer of sidebar */}
          <div className="space-y-1 border-t border-sidebar-border p-3">
            <button
              onClick={() => setLogoutOpen(true)}
              className={cn('flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-500 transition-colors hover:bg-red-50 dark:hover:bg-red-950/30', sidebarCollapsed && 'justify-center')}
              title={sidebarCollapsed ? 'Logout' : undefined}
            >
              <LogOut className="h-5 w-5 shrink-0" />
              {!sidebarCollapsed && <span>Logout</span>}
            </button>
          </div>
        </aside>

        {/* Main */}
        <div className="flex min-h-0 min-w-0 flex-1 flex-col">
          {/* Header */}
          <header className="flex h-16 shrink-0 items-center gap-1.5 border-b border-border bg-card/80 px-3 backdrop-blur sm:gap-2 sm:px-4 lg:px-6">
            <button onClick={() => setMobileNavOpen(true)} className="shrink-0 rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground md:hidden" aria-label="Open menu">
              <Menu className="h-5 w-5" />
            </button>
            <button onClick={toggleSidebar} className="hidden shrink-0 rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground md:flex" aria-label="Toggle sidebar">
              {sidebarCollapsed ? <PanelLeft className="h-5 w-5" /> : <PanelLeftClose className="h-5 w-5" />}
            </button>
            <h1 className="min-w-0 truncate font-serif text-base font-semibold sm:text-lg md:text-xl">{VIEW_TITLES[activeView]}</h1>

            <div className="ml-auto flex shrink-0 items-center gap-1 sm:gap-1.5">
              <button
                onClick={() => setSearchOpen(true)}
                className="flex items-center gap-2 rounded-lg border border-border bg-muted/50 px-2.5 py-1.5 text-sm text-muted-foreground transition hover:bg-muted sm:px-3"
              >
                <Search className="h-4 w-4" />
                <span className="hidden lg:inline">Search...</span>
                <kbd className="hidden rounded border border-border bg-card px-1.5 py-0.5 font-mono text-[10px] lg:inline">⌘K</kbd>
              </button>

              <button onClick={toggleTheme} className="rounded-lg p-2 text-muted-foreground transition hover:bg-muted hover:text-foreground" aria-label="Toggle theme">
                {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>

              <button
                onClick={() => setActiveView('notifications')}
                className="relative rounded-lg p-2 text-muted-foreground transition hover:bg-muted hover:text-foreground"
                aria-label="Notifications"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white ring-2 ring-card">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>

              <div className="mx-0.5 h-6 w-px bg-border sm:mx-1" />

              <button onClick={() => setActiveView('profile')} className="flex items-center gap-2 rounded-lg p-1 pr-2 transition hover:bg-muted">
                <UserAvatar name={user.name} avatar={user.avatar} role={user.role} size="sm" />
                <div className="hidden text-left sm:block">
                  <p className="max-w-[100px] truncate text-sm font-medium leading-tight">{user.name}</p>
                  <p className="text-[10px] text-muted-foreground">{user.role}</p>
                </div>
              </button>
            </div>
          </header>

          {/* Content */}
          <main className="min-h-0 flex-1 overflow-y-auto p-4 lg:p-6">
            <div key={activeView} className="animate-fade-slide">
              {renderView()}
            </div>
          </main>
        </div>
      </div>

      {/* Sticky footer — always at viewport bottom (content scrolls above) */}
      <footer className="relative z-10 shrink-0 border-t border-border bg-card/95 px-4 py-2.5 text-xs text-foreground/60 backdrop-blur lg:px-6">
        <div className="flex flex-col items-center justify-between gap-1 sm:flex-row">
          <p className="flex items-center gap-1.5">
            <GraduationCap className="h-3.5 w-3.5 text-emerald-600" />
            <span className="font-medium text-foreground/80">EduCenterJM</span>
            <span className="text-foreground/40">·</span>
            <span>© {new Date().getFullYear()} Secondary School Management System</span>
          </p>
          <p className="flex items-center gap-1 text-foreground/50">
            Crafted with care for educators & students
          </p>
        </div>
      </footer>

      {/* Mobile nav drawer */}
      <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="h-16 flex flex-row items-center gap-3 border-b border-sidebar-border px-4">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-md">
              {settings?.logo ? <img src={settings.logo} alt="School" className="h-full w-full object-cover" /> : <GraduationCap className="h-5 w-5" />}
            </div>
            <SheetTitle className="font-serif text-base font-bold">
              <span className="text-emerald-600 dark:text-emerald-400">Edu</span>Center<span className="text-emerald-600 dark:text-emerald-400">JM</span>
            </SheetTitle>
          </SheetHeader>
          <nav className="flex-1 space-y-1 overflow-y-auto p-3">
            {nav.map((item) => {
              const Icon = item.icon
              const active = activeView === item.id
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={cn(
                    'group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                    active ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'
                  )}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  <span className="truncate">{item.label}</span>
                  {item.id === 'notifications' && unreadCount > 0 && (
                    <Badge className="ml-auto bg-red-500 px-1.5 py-0 text-[10px] text-white">{unreadCount > 9 ? '9+' : unreadCount}</Badge>
                  )}
                </button>
              )
            })}
          </nav>
          <div className="border-t border-sidebar-border p-3">
            <button
              onClick={() => { setMobileNavOpen(false); setLogoutOpen(true) }}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-500 transition-colors hover:bg-red-50 dark:hover:bg-red-950/30"
            >
              <LogOut className="h-5 w-5 shrink-0" />
              <span>Logout</span>
            </button>
          </div>
        </SheetContent>
      </Sheet>

      <SearchModal />
      <ToastContainer />

      {/* Logout confirm */}
      <AlertDialog open={logoutOpen} onOpenChange={setLogoutOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sign out?</AlertDialogTitle>
            <AlertDialogDescription>You will be returned to the login screen. You can sign back in any time.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={loggingOut}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => doLogout(false)}
              disabled={loggingOut}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {loggingOut ? 'Signing out...' : 'Logout'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Idle warning */}
      <AlertDialog open={idleWarning} onOpenChange={(o) => { if (!o) { setIdleWarning(false); if (idleTimer.current) clearTimeout(idleTimer.current); idleTimer.current = setTimeout(() => setIdleWarning(true), IDLE_LIMIT) } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Still there?</AlertDialogTitle>
            <AlertDialogDescription>
              You&apos;ve been inactive. You&apos;ll be automatically signed out in <span className="font-bold text-amber-600">{idleCountdown}</span> seconds.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button onClick={() => { setIdleWarning(false); if (idleTimer.current) clearTimeout(idleTimer.current); idleTimer.current = setTimeout(() => setIdleWarning(true), IDLE_LIMIT) }} className="bg-emerald-600 text-white hover:bg-emerald-700">
              Stay logged in
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
